# manage.py - placeholder content for expense-tracker
